/*There are n consecutive seat places in a railway carriage. Each place is either empty or occupied by a passenger.

The university team for the Olympiad consists of a student-programmers and b student-athletes. Determine the largest number of students from all a+b students, which you can put in the railway carriage so that:

no student-programmer is sitting next to the student-programmer;
and no student-athlete is sitting next to the student-athlete.
In the other words, there should not be two consecutive (adjacent) places where two student-athletes or two student-programmers are sitting.

Consider that initially occupied seat places are occupied by jury members (who obviously are not students at all).

Input
The first line contain three integers n, a and b (1≤n≤2⋅105, 0≤a,b≤2⋅105, a+b>0) — total number of seat places in the railway carriage, the number of student-programmers and the number of student-athletes.

The second line contains a string with length n, consisting of characters "." and "*". The dot means that the corresponding place is empty. The asterisk means that the corresponding place is occupied by the jury member.

Output
Print the largest number of students, which you can put in the railway carriage so that no student-programmer is sitting next to a student-programmer and no student-athlete is sitting next to a student-athlete.*/

#include <iostream>
using namespace std;

int main() {
  int numSeats,studentA,studentB,totalS,seats[numSeats],cont=0;
  
  cin>>numSeats;
  cin>>studentA;
  cin>>studentB;
  
  for(int i = 0; i < numSeats; i++){
    cin>>seats[i];//reading each seat availabity
    if(seats[i]=='.'){
      cont++;//Asientos disponibles
    }
  }

  totalS=studentA+studentB;//total of actual students

  if(cont<=totalS){
    if(studentA==studentB){
      cout>>cont;
      //if the number of A and B students is diffferent
    }else{
      if(studentA<=(cont/2)){
        cout>>(studentA*2)+1;
      }elseif(studentB<=(cont/2)){
        cout>>(studentB*2)+1;
      }else{
        cout>>cont;
      }
    }

  }else{

    if(studentA==sttudentB){
      cout>>totalS;
    }else{
        if(studentA<studentB){
          cout>>(studentA*2)+1
        }else{
          cout>>(studentB*2)+1
        }
    }

  }
  
}